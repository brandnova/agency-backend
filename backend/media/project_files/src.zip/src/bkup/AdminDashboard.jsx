import React, { useState } from 'react';
import { FiHome, FiFileText, FiFolder, FiMessageSquare, FiHeart, FiSettings, FiMenu, FiSearch, FiEdit2, FiTrash2 } from 'react-icons/fi';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('posts');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [postsTab, setPostsTab] = useState('draft');

  const toggleSidebar = () => setSidebarCollapsed(!sidebarCollapsed);

  const renderContent = () => {
    switch (activeTab) {
      case 'posts':
        return (
          <div className="space-y-4">
            <div className="flex space-x-4 mb-4">
              <button
                className={`px-4 py-2 rounded ${postsTab === 'draft' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
                onClick={() => setPostsTab('draft')}
              >
                Draft
              </button>
              <button
                className={`px-4 py-2 rounded ${postsTab === 'published' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
                onClick={() => setPostsTab('published')}
              >
                Published
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6].map((post) => (
                <div key={post} className="bg-white p-4 rounded-lg shadow">
                  <h3 className="text-lg font-semibold mb-2">Post Title {post}</h3>
                  <p className="text-gray-600 mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500">Category: Technology</span>
                    <div className="space-x-2">
                      <button className="p-2 text-blue-500 hover:bg-blue-100 rounded">
                        <FiEdit2 />
                      </button>
                      <button className="p-2 text-red-500 hover:bg-red-100 rounded">
                        <FiTrash2 />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'comments':
        return (
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="p-4 flex justify-between items-center border-b">
              <h2 className="text-xl font-semibold">Comments</h2>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search comments..."
                  className="pl-8 pr-4 py-2 border rounded-full"
                />
                <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              </div>
            </div>
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 text-left">
                  <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Author</th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Comment</th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Post</th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {[1, 2, 3, 4, 5].map((comment) => (
                  <tr key={comment}>
                    <td className="px-6 py-4 whitespace-nowrap">User {comment}</td>
                    <td className="px-6 py-4">This is a sample comment {comment}</td>
                    <td className="px-6 py-4 whitespace-nowrap">Post Title {comment}</td>
                    <td className="px-6 py-4 whitespace-nowrap">2023-05-{comment.toString().padStart(2, '0')}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button className="text-indigo-600 hover:text-indigo-900 mr-2">Approve</button>
                      <button className="text-red-600 hover:text-red-900">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case 'settings':
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-2xl font-semibold mb-6">Site Settings</h2>
            <form className="space-y-6">
              <div>
                <label htmlFor="siteName" className="block text-sm font-medium text-gray-700">Site Name</label>
                <input type="text" id="siteName" name="siteName" className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
              </div>
              <div>
                <label htmlFor="siteDescription" className="block text-sm font-medium text-gray-700">Site Description</label>
                <textarea id="siteDescription" name="siteDescription" rows="3" className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"></textarea>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="maintenance" name="maintenance" className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded" />
                <label htmlFor="maintenance" className="ml-2 block text-sm text-gray-900">Enable Maintenance Mode</label>
              </div>
              <div>
                <label htmlFor="theme" className="block text-sm font-medium text-gray-700">Theme</label>
                <select id="theme" name="theme" className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                  <option>Light</option>
                  <option>Dark</option>
                  <option>Custom</option>
                </select>
              </div>
              <div>
                <button type="submit" className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        );
      default:
        return <div>Select a tab</div>;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className={`bg-gray-800 text-white ${sidebarCollapsed ? 'w-16' : 'w-64'} flex flex-col transition-all duration-300 ease-in-out`}>
        <div className="p-4 flex items-center justify-between">
          {!sidebarCollapsed && <h1 className="text-2xl font-bold">Admin</h1>}
          <button onClick={toggleSidebar} className="p-2 rounded-md hover:bg-gray-700">
            <FiMenu />
          </button>
        </div>
        <nav className="flex-1">
          <ul className="space-y-2 py-4">
            {[
              { icon: FiHome, label: 'Dashboard', value: 'dashboard' },
              { icon: FiFileText, label: 'Posts', value: 'posts' },
              { icon: FiFolder, label: 'Categories', value: 'categories' },
              { icon: FiMessageSquare, label: 'Comments', value: 'comments' },
              { icon: FiHeart, label: 'Reactions', value: 'reactions' },
              { icon: FiSettings, label: 'Settings', value: 'settings' },
            ].map((item) => (
              <li key={item.value}>
                <button
                  onClick={() => setActiveTab(item.value)}
                  className={`flex items-center space-x-2 w-full p-2 rounded-md ${activeTab === item.value ? 'bg-gray-900' : 'hover:bg-gray-700'}`}
                >
                  <item.icon className={sidebarCollapsed ? 'mx-auto' : ''} />
                  {!sidebarCollapsed && <span>{item.label}</span>}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-auto">
        <header className="bg-white shadow">
          <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-bold text-gray-900">{activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}</h1>
          </div>
        </header>
        <main>
          <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;