import React, { useState } from 'react';
import { FaImage, FaEye, FaSave, FaCog } from 'react-icons/fa';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';

const CreatePost = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [image, setImage] = useState(null);
  const [showPreview, setShowPreview] = useState(false);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => setImage(e.target.result);
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => setImage(e.target.result);
      reader.readAsDataURL(file);
    }
  };

  const togglePreview = () => setShowPreview(!showPreview);

  return (
    <div>
        <Navbar />

        <div className="min-h-screen bg-gray-100 p-8">
            <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="p-8 space-y-6">
                <h1 className="text-3xl font-bold text-center text-gray-800">Create Post</h1>
                
                <input
                    type="text"
                    placeholder="Enter post title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-4 py-2 text-xl font-semibold text-gray-800 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg"
                />

                <div
                    className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center cursor-pointer hover:-translate-y-1 hover:shadow-lg hover:border-blue-500 transition duration-300"
                    onDrop={handleDrop}
                    onDragOver={(e) => e.preventDefault()}
                >
                    <FaImage className="mx-auto text-4xl text-gray-400 mb-2" />
                    <p className="text-gray-600">Drag and drop an image here, or click to select</p>
                    <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="image-upload"
                    />
                    <label htmlFor="image-upload" className="block mt-2 text-blue-500 hover:underline cursor-pointer">
                    Select Image
                    </label>
                </div>

                {image && (
                    <div className="mt-4">
                    <img src={image} alt="Preview" className="max-w-full h-auto rounded-lg shadow-md" />
                    </div>
                )}

                <ReactQuill
                    value={content}
                    onChange={setContent}
                    className="h-auto mb-12"
                    modules={{
                    toolbar: [
                    [{ header: [false, 1, 2, 3, 4, 5, 6] }, { 'header': '1'}, { 'header': '2'}, { 'font': [] }],
                    [{ 'size': [] }],
                    ['bold', 'italic', 'underline', 'strike', 'blockquote'],
                    [{ 'list': 'ordered' }, { 'list': 'bullet' }, { 'indent': '-1' }, { 'indent': '+1' }],
                    [{ 'align': [] }, { 'color': [] }, { 'background': [] }],
                    ['link', 'image', 'video'],
                    ['code-block'],
                    ['clean']
                    ],
                    }}
                />
                </div>
            </div>

            <div className="fixed bottom-8 right-8 flex space-x-4">
                <button
                onClick={togglePreview}
                className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-full shadow-lg transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110"
                >
                <FaEye className="inline-block mr-2" /> Preview
                </button>
                <button className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-full shadow-lg transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110">
                <FaSave className="inline-block mr-2" /> Save
                </button>
                <button className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-full shadow-lg transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110">
                <FaCog className="inline-block mr-2" /> Tools
                </button>
            </div>

            {showPreview && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white p-8 rounded-lg max-w-2xl w-full max-h-screen overflow-y-auto">
                    <h2 className="text-2xl font-bold mb-4">{title}</h2>
                    {image && <img src={image} alt="Post" className="w-full h-auto rounded-lg mb-4" />}
                    <div dangerouslySetInnerHTML={{ __html: content }} />
                    <button
                    onClick={togglePreview}
                    className="sticky bottom-10 mt-4 bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded"
                    >
                    Close Preview
                    </button>
                </div>
                </div>
            )}

        </div>
        <Footer />
    </div>
  );
};

export default CreatePost;