import React from 'react';
import { FaHistory, FaHeart, FaUsers, FaBullseye, FaEnvelope, FaTwitter, FaLinkedin, FaInstagram } from 'react-icons/fa';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';

const AboutPage = () => {
  return (
    <div className="bg-gray-100 min-h-screen">
      <Navbar />
      {/* Hero Section */}
      <div className="relative h-screen">
        <img
          src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
          alt="Hero Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="absolute inset-0 flex flex-col justify-center items-center text-white p-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 text-center">Welcome to Our Story</h1>
          <p className="text-xl md:text-2xl text-center max-w-2xl">Discover the journey, values, and people behind our mission to inspire and inform.</p>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-6 py-3 flex justify-between items-center">
          <a href="#" className="font-bold text-xl text-gray-800">Our Blog</a>
          <div className="hidden md:flex space-x-4">
            <a href="#history" className="text-gray-600 hover:text-gray-800">History</a>
            <a href="#values" className="text-gray-600 hover:text-gray-800">Values</a>
            <a href="#team" className="text-gray-600 hover:text-gray-800">Team</a>
            <a href="#mission" className="text-gray-600 hover:text-gray-800">Mission</a>
            <a href="#contact" className="text-gray-600 hover:text-gray-800">Contact</a>
          </div>
          <button className="md:hidden text-gray-600 focus:outline-none">
            <svg className="h-6 w-6 fill-current" viewBox="0 0 24 24">
              <path d="M4 5h16a1 1 0 0 1 0 2H4a1 1 0 1 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2z"/>
            </svg>
          </button>
        </div>
      </nav>

      <div className="container mx-auto px-6 py-12">
        {/* History Section */}
        <section id="history" className="mb-20">
          <div className="flex items-center mb-6">
            <FaHistory className="text-4xl text-blue-600 mr-4" />
            <h2 className="text-3xl font-bold">Our History</h2>
          </div>
          <p className="text-gray-700 leading-relaxed">
            Founded in 2010, our blog started as a small passion project and has since grown into a trusted source of information and inspiration for millions of readers worldwide. Through dedication and a commitment to quality content, we've established ourselves as leaders in our field.
          </p>
        </section>

        {/* Values Section */}
        <section id="values" className="mb-20">
          <div className="flex items-center mb-6">
            <FaHeart className="text-4xl text-red-600 mr-4" />
            <h2 className="text-3xl font-bold">Our Core Values</h2>
          </div>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <li className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-bold text-xl mb-2">Integrity</h3>
              <p className="text-gray-700">We believe in honest, transparent communication with our readers and partners.</p>
            </li>
            <li className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-bold text-xl mb-2">Innovation</h3>
              <p className="text-gray-700">We constantly seek new ways to improve and provide cutting-edge content.</p>
            </li>
            <li className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-bold text-xl mb-2">Community</h3>
              <p className="text-gray-700">We foster a supportive environment for our readers and team members.</p>
            </li>
            <li className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-bold text-xl mb-2">Excellence</h3>
              <p className="text-gray-700">We strive for the highest quality in everything we do.</p>
            </li>
          </ul>
        </section>

        {/* Team Section */}
        <section id="team" className="mb-20">
          <div className="flex items-center mb-6">
            <FaUsers className="text-4xl text-green-600 mr-4" />
            <h2 className="text-3xl font-bold">Meet Our Team</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: 'John Doe', role: 'Founder & Editor-in-Chief', image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80' },
              { name: 'Jane Smith', role: 'Senior Writer', image: 'https://images.unsplash.com/photo-1619895862022-09114b41f16f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80' },
              { name: 'Mike Johnson', role: 'Technical Editor', image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80' },
            ].map((member, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md text-center">
                <img src={member.image} alt={member.name} className="w-32 h-32 rounded-full mx-auto mb-4 object-cover" />
                <h3 className="font-bold text-xl mb-2">{member.name}</h3>
                <p className="text-gray-600">{member.role}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Mission Statement */}
        <section id="mission" className="mb-20">
          <div className="flex items-center mb-6">
            <FaBullseye className="text-4xl text-purple-600 mr-4" />
            <h2 className="text-3xl font-bold">Our Mission</h2>
          </div>
          <div className="bg-white p-8 rounded-lg shadow-md">
            <p className="text-gray-700 text-lg leading-relaxed">
              Our mission is to empower and inspire our readers with high-quality, insightful content that enriches their lives and broadens their perspectives. We are committed to fostering a community of lifelong learners, encouraging critical thinking, and promoting positive change in the world through the power of knowledge and shared experiences.
            </p>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="mb-20">
          <div className="flex items-center mb-6">
            <FaEnvelope className="text-4xl text-yellow-600 mr-4" />
            <h2 className="text-3xl font-bold">Get in Touch</h2>
          </div>
          <div className="bg-white p-8 rounded-lg shadow-md">
            <p className="text-gray-700 mb-4">We'd love to hear from you! Reach out to us through the following channels:</p>
            <div className="flex space-x-4">
              <a href="#" className="text-blue-500 hover:text-blue-600"><FaTwitter className="text-3xl" /></a>
              <a href="#" className="text-blue-700 hover:text-blue-800"><FaLinkedin className="text-3xl" /></a>
              <a href="#" className="text-pink-500 hover:text-pink-600"><FaInstagram className="text-3xl" /></a>
            </div>
          </div>
        </section>
      </div>

      <Footer />
    </div>
  );
};

export default AboutPage;