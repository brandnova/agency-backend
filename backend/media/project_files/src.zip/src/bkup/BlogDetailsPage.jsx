import React, { useState, useEffect } from 'react';
import { FaSearch, FaBell, FaUser, FaShare, FaThumbsUp, FaHeart, FaLaugh } from 'react-icons/fa';
import { AiOutlineMenu, AiOutlineClose } from 'react-icons/ai';
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';
// import Home from "./pages/Home";
// import About from "./pages/AboutPage";
// import './App.css';

const BlogDetailsPage = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showBottomNav, setShowBottomNav] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 100) {
        setShowBottomNav(true);
      } else {
        setShowBottomNav(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navbar */}
      <Navbar />

      {/* Search Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Search for topics or posts..."
            className="w-full py-2 px-4 pr-10 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          />
          <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-500">
            <FaSearch className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <div className="lg:flex lg:space-x-8">
          {/* Main Content */}
          <div className="lg:w-2/3">
            {/* General Details Section */}
            <div className="mb-4 flex items-center text-sm text-gray-500">
              <span>July 15, 2023</span>
              <span className="mx-2">•</span>
              <span>Technology</span>
              <span className="mx-2">•</span>
              <span>5 min read</span>
              <span className="mx-2">•</span>
              <span>1.2k views</span>
            </div>

            {/* Blog Display */}
            <h1 className="text-3xl font-bold mb-4">The Future of AI: Transforming Industries and Everyday Life</h1>
            <img src="https://via.placeholder.com/800x400" alt="AI illustration" className="w-full h-auto rounded-lg mb-6" />
            <div className="prose max-w-none">
              <p>Artificial Intelligence (AI) is rapidly evolving, promising to revolutionize various sectors and our daily lives. From healthcare to finance, transportation to education, AI's potential seems boundless. This blog post explores the current state of AI and its projected impact on society in the coming years.</p>
              <h2>The Current Landscape of AI</h2>
              <p>AI has already made significant strides in areas such as natural language processing, computer vision, and predictive analytics. Companies like Google, Amazon, and Microsoft are investing heavily in AI research and development, pushing the boundaries of what's possible.</p>
              <h2>AI in Healthcare</h2>
              <p>One of the most promising applications of AI is in healthcare. AI-powered diagnostic tools can analyze medical images with incredible accuracy, often outperforming human experts. AI is also being used to develop personalized treatment plans and predict patient outcomes.</p>
              <h2>The Future of Work</h2>
              <p>As AI continues to advance, it will undoubtedly impact the job market. While some jobs may become obsolete, new roles will emerge. The key will be adapting to this changing landscape through continuous learning and upskilling.</p>
              <h2>Ethical Considerations</h2>
              <p>As AI becomes more prevalent, we must address ethical concerns such as data privacy, algorithmic bias, and the potential for AI to be used maliciously. Developing robust ethical frameworks and regulations will be crucial as we move forward.</p>
              <h2>Conclusion</h2>
              <p>The future of AI is both exciting and challenging. As we continue to push the boundaries of what's possible, it's essential to consider the broader implications of this powerful technology on society as a whole.</p>
            </div>
          </div>

          {/* Sidebar */}
          <div className={`lg:w-1/3 mt-8 lg:mt-0 ${isSidebarOpen ? 'block' : 'hidden'}`}>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <button onClick={toggleSidebar} className="lg:hidden mb-4 text-indigo-600 hover:text-indigo-800">
                {isSidebarOpen ? 'Hide Sidebar' : 'Show Sidebar'}
              </button>
              <h2 className="text-xl font-semibold mb-4">About the Author</h2>
              <div className="flex items-center mb-4">
                <img src="https://via.placeholder.com/100" alt="Author" className="w-16 h-16 rounded-full mr-4" />
                <div>
                  <h3 className="font-semibold">John Doe</h3>
                  <p className="text-sm text-gray-600">AI Researcher & Tech Enthusiast</p>
                </div>
              </div>
              <p className="text-sm text-gray-700 mb-4">John Doe is a renowned AI researcher with over 10 years of experience in the field. He has published numerous papers on machine learning and neural networks.</p>
              <div className="flex space-x-4">
                <a href="#" className="text-blue-500 hover:text-blue-700">Twitter</a>
                <a href="#" className="text-blue-500 hover:text-blue-700">LinkedIn</a>
                <a href="#" className="text-blue-500 hover:text-blue-700">Website</a>
              </div>
            </div>
          </div>
        </div>

        {/* Comment Section */}
        <div className="my-12">
          <h2 className="text-2xl font-bold mb-4">Comments</h2>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <form className="mb-6">
              <textarea
                className="w-full px-3 py-2 text-gray-700 border rounded-lg focus:outline-none focus:border-indigo-500"
                rows="4"
                placeholder="Leave a comment..."
              ></textarea>
              <div className="mt-2 flex justify-between items-center">
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                >
                  Post Comment
                </button>
                <div className="flex space-x-2">
                  <button className="text-gray-500 hover:text-gray-700">
                    <span className="sr-only">Attach image</span>
                    <svg className="h-6 w-6" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
                      <path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                    </svg>
                  </button>
                  <button className="text-gray-500 hover:text-gray-700">
                    <span className="sr-only">Attach video</span>
                    <svg className="h-6 w-6" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
                      <path d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                    </svg>
                  </button>
                </div>
              </div>
            </form>
            <div className="space-y-6">
              <div className="flex">
                <div className="flex-shrink-0 mr-3">
                  <img className="mt-2 rounded-full w-8 h-8 sm:w-10 sm:h-10" src="https://via.placeholder.com/40" alt="User Avatar" />
                </div>
                <div className="flex-1 border rounded-lg px-4 py-2 sm:px-6 sm:py-4 leading-relaxed">
                  <strong>Sarah Thompson</strong> <span className="text-xs text-gray-400">3:34 PM</span>
                  <p className="text-sm">
                    This is a fantastic article! I'm particularly interested in the ethical considerations of AI. How do you think we can ensure that AI development remains responsible and beneficial for all of society?
                  </p>
                  <div className="mt-4 flex items-center">
                    <div className="flex -space-x-2 mr-2">
                      <img className="rounded-full w-6 h-6 border border-white" src="https://via.placeholder.com/24" alt="User Avatar" />
                      <img className="rounded-full w-6 h-6 border border-white" src="https://via.placeholder.com/24" alt="User Avatar" />
                    </div>
                    <div className="text-sm text-gray-500 font-semibold">
                      5 Replies
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex">
                <div className="flex-shrink-0 mr-3">
                  <img className="mt-2 rounded-full w-8 h-8 sm:w-10 sm:h-10" src="https://via.placeholder.com/40" alt="User Avatar" />
                </div>
                <div className="flex-1 border rounded-lg px-4 py-2 sm:px-6 sm:py-4 leading-relaxed">
                  <strong>Alex Johnson</strong> <span className="text-xs text-gray-400">4:15 PM</span>
                  <p className="text-sm">
                    Great insights on AI's impact on healthcare! I work in the medical field, and we're already seeing some amazing applications. Do you have any thoughts on how AI might change medical education in the coming years?
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      {showBottomNav && (
        <div className="sticky bottom-0 left-0 right-0 bg-white shadow-lg py-2 px-4 transition-all duration-300 ease-in-out">
          <div className="max-w-7xl mx-auto px-3 flex justify-between items-center">
            <div className="flex space-x-4">
              <button className="text-gray-500 hover:text-gray-700">
                <FaThumbsUp className="h-6 w-6" />
              </button>
              <button className="text-gray-500 hover:text-gray-700">
                <FaHeart className="h-6 w-6" />
              </button>
              <button className="text-gray-500 hover:text-gray-700">
                <FaLaugh className="h-6 w-6" />
              </button>
            </div>
            <div className="flex space-x-4">
              <button className="text-gray-500 hover:text-gray-700">
                <FaShare className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
};

export default BlogDetailsPage;