import React, { useState } from 'react';
import { FaGithub, FaLinkedin, FaTwitter, FaExternalLinkAlt } from 'react-icons/fa';
import { MdCode, MdWork, MdPerson } from 'react-icons/md';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';

const projects = [
  {
    id: 1,
    title: 'E-commerce Platform',
    description: 'A full-stack e-commerce solution with React and Node.js',
    image: 'https://example.com/ecommerce-project.jpg',
    githubLink: 'https://github.com/username/ecommerce-project',
    liveLink: 'https://ecommerce-project.com',
    tags: ['React', 'Node.js', 'MongoDB']
  },
  {
    id: 2,
    title: 'Weather App',
    description: 'Real-time weather application using OpenWeatherMap API',
    image: 'https://example.com/weather-app.jpg',
    githubLink: 'https://github.com/username/weather-app',
    liveLink: 'https://weather-app-demo.com',
    tags: ['React', 'API Integration', 'CSS3']
  },
  {
    id: 3,
    title: 'Task Management System',
    description: 'A Kanban-style task management app with drag-and-drop functionality',
    image: 'https://example.com/task-management.jpg',
    githubLink: 'https://github.com/username/task-management',
    liveLink: 'https://task-management-demo.com',
    tags: ['React', 'Redux', 'Firebase']
  }
];

const contributions = [
  {
    id: 1,
    title: 'Open Source Library Contribution',
    description: 'Added new features to a popular React component library',
    link: 'https://github.com/popular-library/pull/123'
  },
  {
    id: 2,
    title: 'Tech Blog Article',
    description: 'Wrote an article on optimizing React performance',
    link: 'https://dev.to/username/optimizing-react-performance'
  }
];

const codeSnippets = [
  {
    id: 1,
    title: 'Custom React Hook',
    language: 'javascript',
    code: `const useLocalStorage = (key, initialValue) => {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.log(error);
      return initialValue;
    }
  });

  const setValue = (value) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.log(error);
    }
  };

  return [storedValue, setValue];
};`
  },
  {
    id: 2,
    title: 'React Context Example',
    language: 'javascript',
    code: `import React, { createContext, useContext, useState } from 'react';

const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState('light');

  const toggleTheme = () => {
    setTheme((prevTheme) => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);`
  }
];

const PortfolioPage = () => {
  const [activeSection, setActiveSection] = useState('projects');
  const [modalContent, setModalContent] = useState(null);

  const renderProjects = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* <Navbar /> */}
      {projects.map((project) => (
        <div key={project.id} className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:scale-105">
          <img src={project.image} alt={project.title} className="w-full h-48 object-cover" />
          <div className="p-4">
            <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
            <p className="text-gray-600 mb-4">{project.description}</p>
            <div className="flex flex-wrap gap-2 mb-4">
              {project.tags.map((tag, index) => (
                <span key={index} className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded">
                  {tag}
                </span>
              ))}
            </div>
            <div className="flex justify-between">
              <a href={project.githubLink} target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-gray-900">
                <FaGithub size={24} />
              </a>
              <a href={project.liveLink} target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-gray-900">
                <FaExternalLinkAlt size={24} />
              </a>
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  const renderContributions = () => (
    <div className="space-y-6">
      {contributions.map((contribution) => (
        <div key={contribution.id} className="bg-white rounded-lg shadow-md p-6 transition-transform duration-300 hover:scale-105">
          <h3 className="text-xl font-semibold mb-2">{contribution.title}</h3>
          <p className="text-gray-600 mb-4">{contribution.description}</p>
          <a href={contribution.link} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 flex items-center">
            View Contribution <FaExternalLinkAlt size={16} className="ml-2" />
          </a>
        </div>
      ))}
    </div>
  );

  const renderCodeSnippets = () => (
    <div className="space-y-6">
      {codeSnippets.map((snippet) => (
        <div key={snippet.id} className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="bg-gray-100 px-4 py-2 flex justify-between items-center">
            <h3 className="text-lg font-semibold">{snippet.title}</h3>
            <span className="text-sm text-gray-600">{snippet.language}</span>
          </div>
          <pre className="p-4 overflow-x-auto">
            <code className="language-javascript">{snippet.code}</code>
          </pre>
        </div>
      ))}
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'projects':
        return renderProjects();
      case 'contributions':
        return renderContributions();
      case 'codeSnippets':
        return renderCodeSnippets();
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-md sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <img className="h-8 w-8 rounded-full" src="https://example.com/avatar.jpg" alt="Developer Avatar" />
                <span className="ml-2 text-xl font-bold">John Doe</span>
              </div>
            </div>
            <div className="flex items-center">
              <a href="https://github.com/johndoe" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-gray-900 px-3 py-2">
                <FaGithub size={24} />
              </a>
              <a href="https://linkedin.com/in/johndoe" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-gray-900 px-3 py-2">
                <FaLinkedin size={24} />
              </a>
              <a href="https://twitter.com/johndoe" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-gray-900 px-3 py-2">
                <FaTwitter size={24} />
              </a>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex justify-center mb-8">
          <nav className="flex space-x-4" aria-label="Tabs">
            <button
              onClick={() => setActiveSection('projects')}
              className={`px-3 py-2 font-medium text-sm rounded-md ${activeSection === 'projects' ? 'bg-blue-100 text-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <MdWork className="inline-block mr-1" /> Projects
            </button>
            <button
              onClick={() => setActiveSection('contributions')}
              className={`px-3 py-2 font-medium text-sm rounded-md ${activeSection === 'contributions' ? 'bg-blue-100 text-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <MdPerson className="inline-block mr-1" /> Contributions
            </button>
            <button
              onClick={() => setActiveSection('codeSnippets')}
              className={`px-3 py-2 font-medium text-sm rounded-md ${activeSection === 'codeSnippets' ? 'bg-blue-100 text-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <MdCode className="inline-block mr-1" /> Code Snippets
            </button>
          </nav>
        </div>

        <div className="bg-white shadow-lg rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">{activeSection.charAt(0).toUpperCase() + activeSection.slice(1)}</h2>
          {renderContent()}
        </div>
      </main>

      

      <Footer />

      {modalContent && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-4">{modalContent.title}</h2>
            <p className="text-gray-600 mb-4">{modalContent.description}</p>
            <button
              onClick={() => setModalContent(null)}
              className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PortfolioPage;