import React, { useState, useEffect } from 'react';
import { FaBookmark, FaComment, FaShare, FaHeart, FaEye } from 'react-icons/fa';
import { Link } from 'react-router-dom';
// import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';

const HomePage = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const data = await api.get('/blog/posts/');
        setPosts(data);
      } catch (error) {
        console.error('Error fetching posts:', error);
      }
    };

    fetchPosts();
  }, [api]);
  

  const categories = [
    'Technology', 'Travel', 'Food', 'Lifestyle', 'Fashion', 'Health', 'Fitness', 'Business', 'Art', 'Music'
  ];

  const topics = [
    'Technology', 'Health & Wellness', 'Travel', 'Lifestyle', 'Business', 'Personal Development'
  ];

  
  const suggestedTopics = [
    'Top 10 Productivity Hacks',
    'The Rise of Remote Work',
    'Mindfulness and Mental Health',
    'Innovative Cooking Techniques',
    'Sustainable Fashion Trends'
  ];


  const loadMorePosts = () => {
    setCurrentPage(currentPage + 1);
    // Implement loading more posts here
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans">
      {/* Main Navigation */}
      {/* <Navbar /> */}

      

      {/* Main Content */}
      <main className="container mx-auto md:px-40 p-8 flex flex-col md:flex-row">
        {/* Featured Posts */}
        <div className="md:w-3/4 md:pr-8">
          {/* Category Navigation */}
          <div className="bg-gray-200 overflow-x-auto whitespace-nowrap sticky top-3 mb-3 mx-5 rounded-lg shadow-md z-10 hide-scrollbar">
            <div className="container mx-auto px-4 py-3 flex space-x-5">
              {categories.map((category, index) => (
                <a
                  key={index}
                  href={`#${category.toLowerCase()}`}
                  className="text-gray-600 hover:text-gray-900 transition duration-300 flex justify-center"
                >
                  {category}
                </a>
              ))}
            </div>
          </div>
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-indigo-600"></div>
            </div>
          ) : (
            <div className="space-y-3">
              {posts.map((post) => (
                <Link key={post.id} to={`/post/${post.id}`} className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg hover:scale-105">
                  <div className="p-6 sm:flex sm:items-center sm:justify-between">
                    <div className="sm:flex-1">
                      <header className="flex items-center mb-4">
                      
                        {/* <img src={post.author.avatar} alt={post.author} className="w-8 h-8 rounded-full mr-4" /> */}
                        <div className="flex items-center space-x-3">
                          <p className="text-base font-bold text-gray-900">{post.author}</p>
                          <p className="text-xs text-gray-600">{new Date(post.created_at).toLocaleDateString()}</p>
                        </div>
                      </header>
                      <h1 className="text-2xl font-bold text-gray-900 mb-2"><Link to={`/posts/details/${post.id}/${post.slug}`}>{post.excerpt}</Link></h1>
                      <p className="text-gray-700 mb-4">{post.excerpt}</p>
                      <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                        <div className="flex items-center text-sm">
                          <span className="flex items-center mr-4"><FaEye className="mr-1" /> {post.views}</span>
                          <span className="flex items-center mr-4"><FaComment className="mr-1" /> {post.comments}</span>
                          <span className="flex items-center"><FaHeart className="mr-1" /> {post.likes}</span>
                        </div>
                        <div className="flex text-lg space-x-5">
                          <button 
                            onClick={() => handleBookmark(post.id)} 
                            className={`flex items-center ${post.isBookmarked ? 'text-blue-500' : 'text-gray-600'} hover:text-blue-500 transition-colors duration-200`}
                            aria-label="Bookmark post"
                          >
                            <FaBookmark className="mr-1" />
                          </button>
                          <button className="flex items-center text-gray-600 hover:text-gray-800 transition-colors duration-200" aria-label="Share post">
                          <FaShare className="mr-1" />
                          </button>

                        </div>
                      </div>
                    </div>
                    <div className="mt-6 sm:mt-0 sm:ml-6 sm:flex-shrink-0">
                      {post.cover_image && (
                        <img src={post.cover_image} alt={post.title} className="w-full sm:w-48 h-32 object-cover rounded-md" loading="lazy" />
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
          <div className="flex flex-row space-x-2 justify-center items-center">
            <span className="w-2/5 h-1 mt-8 border border-gray-500 bg-gray-500 "></span>
            <button
              onClick={loadMorePosts}
              className="w-1/5 mt-8 text-xs py-2 bg-gray-100 rounded-lg md:px-6 md:text-base hover:shadow-lg hover:scale-105 transition duration-300"
            >
              Load More
            </button>
            <span className="w-2/5 h-1 mt-8 border border-gray-500 bg-gray-500 "></span>
          </div>
        </div>

        {/* Sidebar */}
        <aside className="md:w-1/4 mt-8 md:mt-0">
          <div className="bg-white rounded-lg shadow-md p-6  mb-8">
            <h3 className="text-xl font-semibold mb-4">Suggested Topics</h3>
            <ul className="space-y-2">
              {suggestedTopics.map((topic, index) => (
                <li key={index}>
                  <a href={`#topic-${index}`} className="text-gray-600 hover:text-gray-800 transition duration-300">{topic}</a>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6  mb-8">
            <h3 className="text-xl font-semibold mb-4">Topics</h3>
            <div className="flex flex-wrap gap-2">
              {topics.map((topic, index) => (
                <span key={index} className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-indigo-600 hover:text-white transition-colors duration-300 cursor-pointer">
                  {topic}
                </span>
              ))}
            </div>
          </div>
        </aside>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default HomePage;