import React, { useState } from 'react';
import { FaSearch, FaChevronDown, FaChevronUp } from 'react-icons/fa';
import { BsFillHouseFill, BsPencilSquare, BsTagsFill, BsPersonFill, BsInfoCircleFill } from 'react-icons/bs';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';

const SiteMap = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedSections, setExpandedSections] = useState([]);

  const siteStructure = [
    {
      name: 'Home',
      icon: <BsFillHouseFill />,
      links: ['Latest Posts', 'Featured Articles', 'Popular This Week']
    },
    {
      name: 'Blog',
      icon: <BsPencilSquare />,
      links: ['Technology', 'Travel', 'Food', 'Lifestyle']
    },
    {
      name: 'Categories',
      icon: <BsTagsFill />,
      links: ['Programming', 'Design', 'Marketing', 'Business']
    },
    {
      name: 'About',
      icon: <BsPersonFill />,
      links: ['Our Story', 'Team', 'Careers']
    },
    {
      name: 'Contact',
      icon: <BsInfoCircleFill />,
      links: ['Get in Touch', 'Support', 'FAQ']
    }
  ];

  const toggleSection = (index) => {
    setExpandedSections(prev =>
      prev.includes(index)
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const filteredStructure = siteStructure.map(section => ({
    ...section,
    links: section.links.filter(link =>
      link.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })).filter(section => section.links.length > 0);

  return (
    <div>
        <Navbar />
        <div className="container mx-auto p-4 bg-white dark:bg-gray-800 transition-colors duration-200">
            <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-white">Site Map</h1>
            <div className="mb-6 relative">
                <input
                type="text"
                placeholder="Search pages..."
                className="w-full p-2 pl-10 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-300 dark:bg-gray-700 dark:text-white dark:border-gray-600"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                />
                <FaSearch className="absolute left-3 top-3 text-gray-400" />
            </div>
            <div className="space-y-4">
                {filteredStructure.map((section, index) => (
                <div key={section.name} className="border-b pb-4 dark:border-gray-700">
                    <button
                    onClick={() => toggleSection(index)}
                    className="flex items-center justify-between w-full text-left focus:outline-none"
                    >
                    <span className="flex items-center text-xl font-semibold text-gray-700 dark:text-gray-300">
                        {section.icon}
                        <span className="ml-2">{section.name}</span>
                    </span>
                    {expandedSections.includes(index) ? <FaChevronUp /> : <FaChevronDown />}
                    </button>
                    {expandedSections.includes(index) && (
                    <ul className="mt-2 ml-6 space-y-1">
                        {section.links.map((link, linkIndex) => (
                        <li key={linkIndex} className="text-blue-600 dark:text-blue-400 hover:underline">
                            <a href="#" onClick={(e) => e.preventDefault()}>{link}</a>
                        </li>
                        ))}
                    </ul>
                    )}
                </div>
                ))}
            </div>
        </div>
        <Footer />

    </div>
  );
};

export default SiteMap;