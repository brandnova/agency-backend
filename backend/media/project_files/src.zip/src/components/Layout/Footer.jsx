// src/components/Footer.jsx
import React, { useState, useEffect } from 'react';
import { FaFacebookF, FaTwitter, FaInstagram, FaChevronUp } from 'react-icons/fa';

const Footer = () => {
    const [showBackToTop, setShowBackToTop] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
          setShowBackToTop(window.pageYOffset > 300);
        };
    
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
      }, []);
    
      const scrollToTop = () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      };
    
  return (
    <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-2xl font-bold">CoderNova</h2>
              <p className="text-gray-400">Discover. Learn. Share.</p>
            </div>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition duration-300">
                <FaFacebookF size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition duration-300">
                <FaTwitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition duration-300">
                <FaInstagram size={20} />
              </a>
            </div>
          </div>
          <div className="my-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} CoderNova. All rights reserved.</p>
          </div>
        </div>

        {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-11 right-8 bg-indigo-600 text-white p-3 rounded-full shadow-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-colors duration-300"
          aria-label="Back to top"
        >
          <FaChevronUp />
        </button>
      )}
    </footer>
    
  );
};

export default Footer;


