// src/components/Navbar.jsx
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FiMenu, FiX } from 'react-icons/fi';
import { FaSearch } from 'react-icons/fa';


const Navbar = ({ user, logout }) => {

    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const navigate = useNavigate();


    useEffect(() => {
        const handleKeyDown = (event) => {
          if (event.key === 'Escape') {
            setIsMenuOpen(false);
          }
        };
    
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
      }, []);
    
      const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
    
      const handleSearch = (e) => {
        e.preventDefault();
        // Implement search functionality here
        console.log('Searching for:', searchQuery);
    };


    const handleLogout = () => {
        logout();
        navigate('/');
    };

    return (
        <nav className="bg-white shadow-md">
            <div className="container mx-auto px-4 py-3 flex justify-between items-center">
                <Link to="/" className="text-2xl font-bold text-gray-800"> CoderNova</Link>
                <div className="hidden md:flex space-x-4">
                    <Link to="/"  className="text-gray-600 hover:text-gray-800">Home</Link>
                    <Link to="/about"  className="text-gray-600 hover:text-gray-800">About</Link>
                    <Link to="/contact"  className="text-gray-600 hover:text-gray-800">Contact</Link>
                    <Link to="/post"  className="text-gray-600 hover:text-gray-800">Post</Link>
                    <Link to="/folio"  className="text-gray-600 hover:text-gray-800">Folio</Link>
                    <Link to="/create-post"  className="text-gray-600 hover:text-gray-800">Create Post</Link>
                    <Link to="/dashboard"  className="text-gray-600 hover:text-gray-800">Dashboard</Link>
                    <Link to="/sitemap"  className="text-gray-600 hover:text-gray-800">SiteMap</Link>
                </div>
                <div className="flex items-center space-x-4">
                    {/* Search Bar */}
                    <form onSubmit={handleSearch} className="hidden md:block">
                        <div className="relative">
                            <input
                                type="text"
                                placeholder="Search..."
                                className="w-full py-2 px-4 pr-10 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            />
                            <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-500">
                                <FaSearch className="h-5 w-5" />
                            </button>
                        </div>
                    </form>
                    <button onClick={toggleMenu} className="md:hidden text-gray-600 hover:text-gray-800">
                    {isMenuOpen ? <FiX size={24} /> : <FiMenu size={24} />}
                    </button>
                    {user ? (
                    <>
                        <span className="text-gray-600">Welcome, {user.username}</span>
                        <button onClick={handleLogout} className="text-gray-600 hover:text-gray-800">Logout</button>
                    </>
                    ) : (
                    <Link to="/auth" className="text-gray-600 hover:text-gray-800">Login/Register</Link>
                    )}
                </div>
            </div>
            {isMenuOpen && (
                <div className="md:hidden bg-white shadow-md">
                    <div className="container mx-auto px-4 py-2 flex flex-col space-y-2">
                        <Link to="/"  className="text-gray-600 hover:text-gray-800">Home</Link>
                        <Link to="/about"  className="text-gray-600 hover:text-gray-800">About</Link>
                        <Link to="/contact"  className="text-gray-600 hover:text-gray-800">Contact</Link>
                        <Link to="/post"  className="text-gray-600 hover:text-gray-800">Post</Link>
                        <Link to="/folio"  className="text-gray-600 hover:text-gray-800">Folio</Link>
                        <form onSubmit={handleSearch}>
                            <div className="relative">
                                <input
                                    type="text"
                                    placeholder="Search for topics or posts..."
                                    className="w-full py-2 px-4 pr-10 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                                />
                                <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-500">
                                    <FaSearch className="h-5 w-5" />
                                </button>
                            </div>
                        </form>
                        {user ? (
                        <>
                            <span className="text-gray-600">Welcome, {user.username}</span>
                            <button onClick={handleLogout} className="text-gray-600 hover:text-gray-800">Logout</button>
                        </>
                        ) : (
                        <Link to="/auth" className="text-gray-600 hover:text-gray-800">Login/Register</Link>
                        )}
                    </div>
                </div>
            )}
        </nav>

    );
};

export default Navbar;
