// src/hoc/withApi.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000/api'; // Update this with your API base URL

const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
});

export const withApi = (WrappedComponent) => {
  return function WithApiComponent(props) {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
      const token = localStorage.getItem('access_token');
      if (token) {
        axiosInstance.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        fetchUser();
      } else {
        setLoading(false);
      }
    }, []);

    const fetchUser = async () => {
      try {
        const response = await axiosInstance.get('/auth/user/');
        setUser(response.data);
      } catch (error) {
        console.error('Error fetching user:', error);
      } finally {
        setLoading(false);
      }
    };

    const login = async (credentials) => {
      try {
        const response = await axiosInstance.post('/auth/token/', credentials);
        localStorage.setItem('access_token', response.data.access);
        localStorage.setItem('refresh_token', response.data.refresh);
        axiosInstance.defaults.headers.common['Authorization'] = `Bearer ${response.data.access}`;
        await fetchUser();
        return true;
      } catch (error) {
        console.error('Login error:', error);
        return false;
      }
    };

    const logout = () => {
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
      delete axiosInstance.defaults.headers.common['Authorization'];
      setUser(null);
    };

    const register = async (userData) => {
      try {
        await axiosInstance.post('/auth/register/', userData);
        return true;
      } catch (error) {
        console.error('Registration error:', error);
        return false;
      }
    };

    const refreshToken = async () => {
      const refreshToken = localStorage.getItem('refresh_token');
      if (refreshToken) {
        try {
          const response = await axiosInstance.post('/auth/token/refresh/', { refresh: refreshToken });
          localStorage.setItem('access_token', response.data.access);
          axiosInstance.defaults.headers.common['Authorization'] = `Bearer ${response.data.access}`;
          return true;
        } catch (error) {
          console.error('Token refresh error:', error);
          logout();
          return false;
        }
      }
      return false;
    };

    const apiCall = async (method, endpoint, data = null) => {
      try {
        const response = await axiosInstance[method](endpoint, data);
        return response.data;
      } catch (error) {
        if (error.response && error.response.status === 401) {
          const refreshed = await refreshToken();
          if (refreshed) {
            return apiCall(method, endpoint, data);
          } else {
            throw error;
          }
        }
        throw error;
      }
    };

    const api = {
      get: (endpoint) => apiCall('get', endpoint),
      post: (endpoint, data) => apiCall('post', endpoint, data),
      put: (endpoint, data) => apiCall('put', endpoint, data),
      delete: (endpoint) => apiCall('delete', endpoint),
    };

    return (
      <WrappedComponent
        {...props}
        api={api}
        user={user}
        loading={loading}
        login={login}
        logout={logout}
        register={register}
      />
    );
  };
};