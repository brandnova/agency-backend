// // src/App.jsx
// import React from 'react';
// import { Routes, Route, Link } from 'react-router-dom';
// import { withApi } from './hoc/withApi';
// import Home from './pages/HomePage';
// import About from './pages/AboutPage';
// import Contact from './pages/ContactPage';
// import DetailsPage from './pages/DetailsPage';
// import FolioPage from './pages/FolioPage';
// import CreatePost from './pages/CreatePost';
// import AdminDashboard from './pages/AdminDashboard';
// import SiteMap from './pages/SiteMap';


// function App({ api, user, loading, login, logout, register }) {
//   return (
//     <div>
      
//       <Routes>
//         <Route path="/" element={<Home />} />
//         <Route path="/about" element={<About />} />
//         <Route path="/contact" element={<Contact />} />
//         <Route path="/posts/details/:id/:slug" element={<DetailsPage />} />
//         <Route path="/folio" element={<FolioPage />} />
//         <Route path="/create-post" element={<CreatePost />} />
//         <Route path="/dashboard" element={<AdminDashboard />} />
//         <Route path="/sitemap" element={<SiteMap />} />

//       </Routes>
//     </div>
//   );
// }

// export default withApi(App);

import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { withApi } from './hoc/withApi';
import Navbar from './components/Layout/Navbar';
import Home from './pages/HomePage';
import BlogDetailsPage from './pages/BlogDetailsPage';
import AuthPage from './pages/AuthPage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';
import ResetPasswordPage from './pages/ResetPasswordPage';

function App({ user, loading, logout }) {
  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <Navbar user={user} logout={logout} />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/posts/details/:id/:slug" element={<BlogDetailsPage />} />
        <Route 
          path="/auth" 
          element={user ? <Navigate to="/" replace /> : <AuthPage />} 
        />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        <Route path="/reset-password/:uid/:token" element={<ResetPasswordPage />} />
      </Routes>
    </div>
  );
}

export default withApi(App);